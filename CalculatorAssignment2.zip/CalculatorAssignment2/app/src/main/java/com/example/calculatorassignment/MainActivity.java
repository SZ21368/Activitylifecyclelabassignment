package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.calculatorassignment.R;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private EditText Value1, Value2, reResult;
    private Button btnCalculate;
    private Spinner spSpinner;
    private int value1=0; int value2=0;
    private int result;
    private TextView item;
    ArrayList<String> listarray;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Value1=findViewById(R.id.Value1);
        Value2=findViewById(R.id.Value2);
        btnCalculate=findViewById(R.id.btnCalculate);
        reResult=findViewById(R.id.reResult);
        spSpinner=findViewById(R.id.spSpinner);
        item=findViewById(R.id.item);
        listarray=new ArrayList<String>();

        listarray.add("ADD");
        listarray.add("SUBTRACT");
        listarray.add("DIVIDE");
        listarray.add("MULTIPLY");

        ArrayAdapter adapter=new ArrayAdapter(MainActivity.this,R.layout.item,R.id.item,listarray);
        spSpinner.setAdapter(adapter);


        btnCalculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                value1=Integer.parseInt(Value1.getText().toString());
                value2=Integer.parseInt(Value2.getText().toString());

                if(spSpinner.getSelectedItem().toString()=="ADD"){
                    result=value1+value2;
                    reResult.setText(String.valueOf(result));
                }

                else if(spSpinner.getSelectedItem().toString()=="SUBTRACT"){
                    result=value1-value2;
                    reResult.setText(String.valueOf(result));
                }

                else if(spSpinner.getSelectedItem().toString()=="DIVIDE"){
                    if (value2==0)
                    {
                        Toast.makeText(MainActivity.this, "Dividing a number with 0", Toast.LENGTH_LONG).show();
                    }
                    else{
                        result=value1/value2;
                        reResult.setText("Qoutient: " +String.valueOf(result)+"Remainder: " +String.valueOf(value1/value2));
                    }

                }
                else if(spSpinner.getSelectedItem().toString()=="MULTIPLY"){
                    result=value1*value2;
                    reResult.setText(String.valueOf(result));
                }
                else{
                    Toast.makeText(MainActivity.this, "INVALID", Toast.LENGTH_LONG).show();
                }



            }

        });







    }
}